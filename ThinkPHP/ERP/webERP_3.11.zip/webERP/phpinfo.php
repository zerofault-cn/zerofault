<?php
/* $Revision: 1.3 $ */
phpinfo();

?> 
