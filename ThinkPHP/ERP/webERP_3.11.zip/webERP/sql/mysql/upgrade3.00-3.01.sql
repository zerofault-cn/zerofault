ALTER TABLE www_users CHANGE language language char(5) NOT NULL DEFAULT 'en_GB';
