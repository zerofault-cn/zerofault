Some Icons sourced via Creative Commons Attribution 2.5 License.

http://www.famfamfam.com/lab/icons/silk/
