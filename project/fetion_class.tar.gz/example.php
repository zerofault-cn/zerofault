<?php
/**
 * Fetion class USAGE 
 * @author Hellex <Hellex@Band7.com>
 */
 
set_time_limit(0) ;
include 'fetion.class.php' ;

$fetion = new fetion() ;
//sign in
$fetion->sign_in ('13800138***', '123456') ;
//send sms
$fetion->send_sms('13800138***', 'test...') ;

