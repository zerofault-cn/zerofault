<?php
/**
 * Project:  Fetion class 
 * File:     fetion.class.php
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * @author Hellex <Hellex@Band7.com>
 * @copyright (c) 2009, Hellex 
 * @link http://hellex.cn
 * @version 0.1 2009/07/19 
 *
 * USAGE :
 *
 * $fetion = new fetion();
 * $fetion->sign_in ( '13800138***' , '123456' ) ;
 * $fetion->send_sms( '13800138***' , 'This message was sent by fetion class.' ) ;
 *
 */

# protocol
define ( 'FETION_SIPP', 'SIPP' ) ;
define ( 'FETION_CONFIG_URL' , 'http://nav.fetion.com.cn/nav/getsystemconfig.aspx' ) ;
define ( 'FETION_CONFIG_XML' , '<config><user mobile-no="%s" /><client type="PC" version="3.2.0540" platform="W5.1" /><servers version="0" /><service-no version="0" /><parameters version="0" /><hints version="0" /><http-applications version="0" /><client-config version="0" /></config>' ) ; //%s=cell phone
define ( 'FETION_SIP_R_ARGS' , '<args><device type="PC" version="0" client-version="3.2.0540" /><caps value="simple-im;im-session;temp-group;personal-group" /><events value="contact;permission;system-message;personal-group" /><user-info attributes="all" /><presence><basic value="400" desc="" /></presence></args>' ) ; // REGISTER ARGS

define ( 'FETION_SIPC_REGISTER'  , 'R %s SIP-C/2.0' ) ; // 'R [domain] SIP-C/2.0'
define ( 'FETION_SIPC_MESSAGE'   , 'M %s SIP-C/2.0' ) ; // 'M [domain] SIP-C/2.0'
define ( 'FETION_SENDSMS_NOTIFY' , 'SendSMS' ) ;
define ( 'FETION_CURL_USERAGENT' , 'IIC2.0/PC 3.2.0540' ) ;
define ( 'CHAR_DEFAULT_BREAKER'  , "\r\n" ) ;


# messages
define ( 'MSG_PARSE_SSIC_ERROR' , 'Parse ssic error, Check your mobile number or password.' ) ;
define ( 'MSG_PARSE_SIP_ERROR' , 'Can not parse SIP' ) ;
define ( 'MSG_FAIL_SEND_SMS' , 'Send sms unsuccessfully' ) ;
define ( 'MSG_FAIL_REG_SRV' , 'Register server unsuccessfully' ) ;
define ( 'MSG_NO_NONCE' , 'Fetion Error: no nonce found' ) ;

class fetion
{
    # curl/fetion configure  
    public $curl_response_split = "\r\n\r\n" ; // split header and body
    public $curl_ssl_pattern    = '/https:\/\//' ;
    public $fetion_signin_query = '?mobileno=%s&pwd=%s' ; //%s=cell phone , password
    public $fetion_tunnel_query = '?t=%s&i=%d' ; 
    public $fetion_reg_answer   = "Digest algorithm=\"SHA1-sess\",response=\"%s\",cnonce=\"%s\",salt=\"%s\"" ; //register answer
    public $fetion_curl_headers ;
    
    # patterns
    public $sign_in_pattern       = '/<ssi\-app\-sign\-in>(.*)<\/ssi\-app\-sign\-in>/' ;
    public $http_tunnel_pattern   = '/<http\-tunnel>(.*)<\/http\-tunnel>/' ;
    public $check_ssic_pattern    = '/Set-Cookie: ssic=(.*);/';
    public $check_sip_pattern     = '/sip:(\d+)@(.+);/';
    public $check_nonce_pattern   = '/nonce="(\w+)"/s' ;
    public $check_sendsms_pattern = '/Send SMS OK/' ;
    public $check_regsrv_pattern  = '/SIP\-C\/2.0 200 OK/' ;
    
    private $sign_in_url ;
    private $http_tunnel ;
    private $ssic ;
    private $sip ;

    private $guid ;
    private $salt_string ;
    private $cell ;
    private $password ;

    /**
     * Constructor
     * no prama
     */
    public function __construct(){}

    /**
     * Sign in  &  register server
     * @prama  string  $cell
     * $prama  string  $password
     * return boolean
     *
     */
    public function sign_in( $cell , $password )
    {
        $this->cell     = $cell ;
        $this->password = $password ;

        $this->gen_hash() ; 
        $this->fetion_curl_headers = array( 'Content-Type: application/oct-stream', 'Pragma: xz4BBcV'.$this->guid ) ;
        $response = $this->curl_request( FETION_CONFIG_URL , sprintf( FETION_CONFIG_XML , $cell ) );
        $this->sign_in_url  = $this->search_element( $this->sign_in_pattern , $response[1] ) ;
        $this->http_tunnel  = $this->search_element( $this->http_tunnel_pattern , $response[1] ) ;      
             
        #sign in 
        $request_url = $this->sign_in_url . sprintf( $this->fetion_signin_query , $cell , $password ) ;
        $response    = $this->curl_request( $request_url ) ;
        ! preg_match( $this->check_ssic_pattern , $response[0]/*response header*/ , $matches ) 
        && $this->error( MSG_PARSE_SSIC_ERROR );
        $this->ssic = $matches[1] ;

        ! preg_match( $this->check_sip_pattern , $response[1]/*response body*/ , $matches ) 
        && $this->error( MSG_PARSE_SIP_ERROR ) ;
        $this->user['sid']    = $matches[1] ;
        $this->user['domain'] = $matches[2] ; 
        
        return $this->register_server() ;
    }

    /**
     * send sms to a target cell phone
     * @prama  string  $cell
     * $prama  string  $message
     * return boolean
     *
     */
    public function send_sms( $cell , $message )
    {
        $sip = $this->create_sip( FETION_SIPC_MESSAGE , array( 'Q'=>'1 M', 'T'=>'tel:'.$cell , 'N'=> FETION_SENDSMS_NOTIFY ) , $message );
        $this->curl_request( $this->get_request_uri() , $sip ) ;	
        $response = $this->curl_request( $this->get_request_uri() ) ;
    
        !preg_match( $this->check_sendsms_pattern , $response[1] ) 
        && $this->error( MSG_FAIL_SEND_SMS ) ;
        return true ; 
    }
    
    private function gen_hash()
    {
        $hash = md5 ( uniqid ( rand() , true ) . getenv('REMOTE_ADDR') ) ; 
        $split_hash = str_split( $hash , 4 ) ;
        $this->guid = $split_hash[0] . $split_hash[1] . '_' . $split_hash[2] . '_'  
                    . $split_hash[3] . '_' . $split_hash[4] . '_'
                    . $split_hash[5] . $split_hash[6] . $split_hash[7] ;
                    
        $salt_string = '' ;
        $i = 0 ;
        while( $i < 32 )
        {
             if ( !is_numeric( $hash[$i] ) ) $salt_string .= $hash[$i] ;
             $i++ ;
        }
        if ( strlen( $salt_string ) < 4 ) $salt_string = 'Faint!!!!!' ;
        $this->salt_string = substr( $salt_string , 0 , 4 ) ;
    }
    
    # CURLOPT_HEADER = true
    # DEFAULT POSTFIELDS = FETION_SIPP
    private function curl_request( $url , $postfields = '' ) 
    {
        $ch = curl_init();
        curl_setopt( $ch , CURLOPT_URL, $url ) ;
        curl_setopt( $ch , CURLOPT_USERAGENT, FETION_CURL_USERAGENT  ) ;
        curl_setopt( $ch , CURLOPT_RETURNTRANSFER, true ) ;
        curl_setopt( $ch , CURLOPT_HTTPHEADER, $this->fetion_curl_headers ) ;
        curl_setopt( $ch , CURLOPT_HEADER, true ) ;
        ($this->ssic) && curl_setopt( $ch, CURLOPT_COOKIE, 'ssic=' . $this->ssic );

        if( preg_match( $this->curl_ssl_pattern  , $url ) ) 
        {
            curl_setopt( $ch , CURLOPT_SSL_VERIFYHOST, false ) ;
            curl_setopt( $ch , CURLOPT_SSL_VERIFYPEER, false ) ; 
        }
        
        curl_setopt( $ch , CURLOPT_POST , true ) ;
        curl_setopt( $ch , CURLOPT_POSTFIELDS, ( !$postfields ) ? FETION_SIPP : $postfields ) ;
        
        $response = curl_exec( $ch ) ;
        !$response && $this->error( curl_error( $ch ) ) ;
        curl_close($ch) ;
        return explode( $this->curl_response_split , $response ) ; 
    }
    
    private function register_server()
    {
        #get nonce
        $sip = $this->create_sip( FETION_SIPC_REGISTER , array( 'Q'=>'1 R' ) , FETION_SIP_R_ARGS ) ;            
        $this->curl_request( $this->get_request_uri('i') , $sip ) ;
        $response = $this->curl_request( $this->get_request_uri() ) ;
        !preg_match( $this->check_nonce_pattern , $response[1] , $matches ) 
        && $this->error( MSG_NO_NONCE ) ;
        $cnonce = $this->gen_cnonce() ;
        $sip = $this->create_sip( FETION_SIPC_REGISTER  , 
                                  array( 'Q'=> '2 R', 
                                         'A'=> sprintf( $this->fetion_reg_answer , 
                                                        $this->gen_response( $matches[1]/*nonce*/ , $cnonce ) ,
                                                        $cnonce ,
                                                        substr( $this->hash_password() , 0 , 8 ) ) ) ,
                                  FETION_SIP_R_ARGS 
                                 ) ;
        $this->curl_request( $this->get_request_uri() , $sip );
        $response =  $this->curl_request( $this->get_request_uri() ) ;
        !preg_match( $this->check_regsrv_pattern , $response[1]/*response body*/ ) 
        && $this->error( MSG_FAIL_REG_SRV ) ;
        return true ;
    }

    private function create_sip( $sip_function , $elements , $args )
    {
        $sip = sprintf( $sip_function , $this->user['domain'] ) . CHAR_DEFAULT_BREAKER 
             . 'F: ' . $this->user['sid'] . CHAR_DEFAULT_BREAKER
             . 'I: ' . $this->next_call() . CHAR_DEFAULT_BREAKER  ;
        foreach ( $elements as $key => $value ) 
        {
            $sip .= $key . ': ' . $value . CHAR_DEFAULT_BREAKER ;
        }
        $sip .= 'L: ' . strlen( $args ) . CHAR_DEFAULT_BREAKER.CHAR_DEFAULT_BREAKER . $args . FETION_SIPP ;
        return $sip ;
    }
    
    private function get_request_uri( $t = 's' ) 
    {
        static $i = 0;
        ++$i;
        return $this->http_tunnel . sprintf( $this->fetion_tunnel_query , $t , $i ) ;
    }

    private function search_element( $parttern , $subject )
    {
        preg_match( $parttern , $subject , $matches ) ;
        return $matches[1];
    }
    
    private function next_call() 
    {
        static $call_id = 0 ;
        ++$call_id ;
        return $call_id ;
    }

    private function hex2bin( $hex_string ) 
    {
        $len = strlen( $hex_string ) ;
        $i   = 0 ;
        $bin_string = '' ;
        while( $i < $len )
        {
            $bin_string .= chr( hexdec ( $hex_string[$i] . $hex_string[$i+1] ) ) ;
            $i += 2 ;
        }
        return $bin_string ;
    }
    
    private function hash_password()
    {
        return strtoupper( bin2hex( $this->salt_string . sha1( $this->salt_string . hash( 'sha1' , $this->password , true ) , true ) ) ) ;
    }
    
    private function gen_cnonce() 
    {
        return sprintf( "%X%X%X%X%X%X%X%X", $this->salt_string[0], $this->salt_string[1], $this->salt_string[2], $this->salt_string[3], 
                                            $this->salt_string[3], $this->salt_string[2], $this->salt_string[1], $this->salt_string[0] ) ;
    }
    
    private function gen_response( $nonce , $cnonce )
    {
        $key = sha1( $this->user['sid'].':'.$this->user['domain'].':'.$this->hex2bin( substr( $this->hash_password(), 8 ) ) , true ) ;
        $knc  = strtoupper( md5( $key . ':' . $nonce . ':' . $cnonce ) ) ;
        return strtoupper( md5( $knc . ':' . $nonce.':'.strtoupper( md5( 'REGISTER:'. $this->user['sid'] ) ) ) ) ;
    }
    
    private function error( $error )
    {
        exit( $error );
    }
}
