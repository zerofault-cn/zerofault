This directory is used internally by Talk.
Do not install additional files here; use "themes\user\" instead.
Everything in this directory will be deleted whenever Talk updates.

Directories:

chat/    This directory is scanned for chat themes.
common/  This directory contains files that are used throughout Talk.
