User-installed themes should be placed here.
The directory will be removed if Talk is uninstalled, but _not_ when Talk is updated.

Directories:

chat/    This directory is scanned for chat themes.
